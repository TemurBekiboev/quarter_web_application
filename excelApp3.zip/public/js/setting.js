$(document).ready(function(){
    $('#region').on('change',function(){
        $("#city").html("");
        $.ajax({
            url: "{{route('city-data')}}",
            type: "POST",
            data: {
                region_id: $(this).val(),
                _token: '{{csrf_token()}}',
            },
            dataType: "json",
            success: function (result) {
                // console.log(result);
                var cityData = JSON.parse(JSON.stringify(result));
                console.log(cityData[0].id);
                $.each(cityData, function (key, value) {
                    $("#city").append('<option value="' + value.id + '">' + value.name + "</option>");
                });
                $("#quarter").html('<option value="">Select State First</option>');
            },
            error: (error) => {
                     console.log(JSON.stringify(error));
   }
        });
    });
    $('#city').on('change',function(){
        $("#quarter").html("");
        $.ajax({
            url: "{{route('quarter-data')}}",
            type: "POST",
            data: {
                district_id: $(this).val(),
                _token: '{{csrf_token()}}',
            },
            dataType: "json",
            success: function (result) {
                // console.log(result);
                var quarterData = JSON.parse(JSON.stringify(result));
                console.log(quarterData[0].id);
                $.each(quarterData, function (key, value) {
                    $("#quarter").append('<option value="' + value.id + '">' + value.name + "</option>");
                });
            },
            error: (error) => {
                     console.log(JSON.stringify(error));
   }
        });
    });
    })