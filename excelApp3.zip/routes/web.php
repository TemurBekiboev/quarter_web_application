<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ExcelFileController;
use App\Http\Controllers\QuarterController;
use App\Http\Controllers\CitizenController;
use App\Http\Controllers\CitizenProfileController;
use App\Http\Controllers\Auth\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/settings', function(){
    return view('setting.main');
});
Route::get('/citizen', [CitizenController::class,'index'])->name('add-citizen');
Route::get('/region', [QuarterController::class,'index'])->name('add-quarter');
Route::post('/city', [QuarterController::class,'cityData'])->name('city-data');
Route::post('/quarter', [QuarterController::class,'quarterData'])->name('quarter-data');
Route::post('/settings', [QuarterController::class,'create'])->name('add-quarter-info');
Route::post('/citizen',[CitizenController::class,'store'])->name('create-citizen');

Route::post('/citizen-login',[LoginController::class,'citizensLogin'])->name('citizens-check');
Route::get('/citizen-profile',[LoginController::class,'showCitizensLoginForm'])->name('citizen-profile');
Route::group(['middleware'=>'auth:citizens'],function (){
    Route::get('/citizen-profile-info',[CitizenProfileController::class,'index'])->name('citizen-profile-logged')->middleware('auth:citizens');
    Route::post('/update-citizen',[CitizenProfileController::class,'update'])->name('update-citizen');
});

Route::get('/',function(){
  return view('indexs');
});

Auth::routes([
    'register' => true
]);
//Auth::routes();
Route::group(['middleware'=>'auth'],function (){
    Route::get('/qaurter-profile-info',[\App\Http\Controllers\QuarterProfileController::class,'index'])->name('quarter-profile-info');
    Route::get('/qaurter-citizens-info/{file_id}', [ExcelFileController::class,'importFiles'])->name('quarter-citizens-info');
});



// Route::post('/file',[ExcelFileController::class,'import'])->name('file-get');



//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


