 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/setting.css')); ?>" rel="stylesheet">
    

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
 </head>
 <body>
  <table class="table table-light">
    <thead class="thead-dark">
      <tr>
        <th>#</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <form action="<?php echo e(route('create-citizen')); ?>" method="post">
          <?php echo csrf_field(); ?>
        <td><?php echo e($user->id); ?></td>
        <td>
        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->region_id == $region->id): ?>
                <?php echo e($region->name); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->district_id == $city->id): ?>
                <?php echo e($city->name); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
          <?php $__currentLoopData = $quarters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quarter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($user->quarter_id == $quarter->id): ?>
              <?php echo e($quarter->name); ?>

          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
          <?php $__currentLoopData = $streets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $street): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($user->street_id == $street->id): ?>
              <?php echo e($street->name); ?>

          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td>
          <?php $__currentLoopData = $quarterFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quarterFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($user->street_id == $quarterFile->street_id): ?>
          <input type="hidden" name="file_id" value="<?php echo e($quarterFile->id); ?>">
              <?php if($quarterFile->confirmed): ?>
                  confirmed
              <?php else: ?>
              <button class="btn btn-success" type="submit">Yaratish</button>
              <?php endif; ?>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
      </form>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
      <tr>
        <th>#</th>
      </tr>
    </tfoot>
  </table>
 </body>
 </html><?php /**PATH C:\xampp\htdocs\excelApp3_1\excelApp3\resources\views/setting/citizenRegister.blade.php ENDPATH**/ ?>