<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Document</title>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/setting.css')); ?>" rel="stylesheet">
    

    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
</head>
<body>
    <div class="container">
       <?php if(in_array(request()->route()->getName(), ['login', 'register'])): ?>
           
       <?php else: ?>
           
       <?php endif; ?>
        <div class="row quarter-form">
            <form action="<?php echo e(route('add-quarter-info')); ?>" method="post" enctype="multipart/form-data">
                
                <?php echo csrf_field(); ?>
                <div class="container-fluid">
                    <h1>Mahalla registratsiyasi</h1>
                    <div class="form-group">
                        <label for="my-input">Login</label>
                        <input id="my-input" class="form-control" type="text" name="username">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Email</label>
                        <input id="my-input" class="form-control" type="text" name="email">
                    </div>
                       <div class="mb-3">
                        <label for="" class="form-label">Maxfiy so'z</label>
                <input type="password" class="form-control" name="password" id="password" placeholder=""/>
                         </div>
                         <?php if(!empty($regions)): ?>
                         <div class="row mb-3">
                            <div class="form-group">
                                <label for="region">Viloyatlar</label>
                                
                                <select id="region" class="form-control" name="region">
                                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                                    
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="row mb-3">
                            <div class="form-group">
                                <label for="city">Shaxar yoki tuman</label>
                                <select id="city" class="form-control" name="city">
                                    <option>Shaharni tanlash</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="form-group">
                                <label for="quarter">Mahalla</label>
                                <select id="quarter" class="form-control" name="quarter">
                                    <option>Mahallani tanlash </option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="file" class="col-md-4 col-form-label text-md-end"><?php echo e(__('File')); ?></label>

                            <div class="col-md-6">
                                <input id="file" type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" required autofocus>

                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div> 
                    
                        <button class="btn btn-primary" type="submit">Saqlash</button> 
                   
                          
            </form>
        </div>
        
    </div>
    <script>
        $(document).ready(function(){
    $('#region').on('change',function(){
        $("#city").html("");
        $.ajax({
            url: "<?php echo e(route('city-data')); ?>",
            type: "POST",
            data: {
                region_id: $(this).val(),
                _token: '<?php echo e(csrf_token()); ?>',
            },
            dataType: "json",
            success: function (result) {
                // console.log(result);
                var cityData = JSON.parse(JSON.stringify(result));
                console.log(cityData[0].id);
                $.each(cityData, function (key, value) {
                    $("#city").append('<option value="' + value.id + '">' + value.name + "</option>");
                });
                $("#quarter").html('<option value="">Select State First</option>');
            },
            error: (error) => {
                     console.log(JSON.stringify(error));
   }
        });
    });
    $('#city').on('change',function(){
        $("#quarter").html("");
        $.ajax({
            url: "<?php echo e(route('quarter-data')); ?>",
            type: "POST",
            data: {
                district_id: $(this).val(),
                _token: '<?php echo e(csrf_token()); ?>',
            },
            dataType: "json",
            success: function (result) {
                // console.log(result);
                var quarterData = JSON.parse(JSON.stringify(result));
                console.log(quarterData[0].id);
                $.each(quarterData, function (key, value) {
                    $("#quarter").append('<option value="' + value.id + '">' + value.name + "</option>");
                });
            },
            error: (error) => {
                     console.log(JSON.stringify(error));
   }
        });
    });
    })
    </script>
</body>
</html><?php /**PATH D:\Programms\newXampp\htdocs\excelApp3\resources\views/setting/registerMain.blade.php ENDPATH**/ ?>