<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <style>
        .form-group label{
            border:1px white solid !important;
            cursor: pointer;
            padding: 3px;
        }
        #excelFile{
            display: none;
            
        }
        .img-excel{
            width: 50px;
            height: 50px;
            cursor: pointer;
        }
       
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
           
                <div class="container text-center" style="background-color: #107d7e; padding:5px;">
                <div class="row">
                    <div class="col">
                <form action="<?php echo e(route('file-get')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                    <div class="form-group file-get">
                        <label for="excelFile" style="color:aliceblue">Выберите Excel
                        <img class="img-excel" src="<?php echo e(asset('/img/logo.png')); ?>" alt="">
                    </label>
                        <input id="excelFile" class="form-control-file" type="file" name="excelFile" onchange="javascript:this.form.submit()">
                    </div>
                </form>
            </div>
            <div class="col">sdfdS</div>
            </div>
        </div>
            
        </div>
       
    <div class="row">
    <table class="table table-hover">
        
        <tbody>
          <?php if(!empty($datas)): ?>
          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php $__currentLoopData = $dt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <tr>
            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
            <td><?php echo e($item); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
         
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
              
          <?php endif; ?>
          
        </tbody>
      </table>
    </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\excelApp\resources\views/welcome.blade.php ENDPATH**/ ?>